package pt.ulusofona.cm.kotlin.challenge

import pt.ulusofona.cm.kotlin.challenge.models.*
import java.time.LocalDate
import java.util.*
import java.text.SimpleDateFormat


fun main() {
    // aqui escreves o código do programa
    //val pessoa1 = Pessoa("Rui", LocalDate.of(1992,2,10))

    //println(pessoa1.toString())
    //pessoa1.pesquisarVeiculo("ABC") // Lança exception
}
