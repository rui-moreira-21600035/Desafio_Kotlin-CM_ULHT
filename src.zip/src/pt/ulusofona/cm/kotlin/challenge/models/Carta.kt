package pt.ulusofona.cm.kotlin.challenge.models

class Carta(){

}
